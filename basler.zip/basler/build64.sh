#!/bin/bash

# this will make the script abort on any error
set -e
set -o pipefail

# Run this script from the pybox/src/basler folder as: ./build.sh

if [[ $(pwd) =~ ^.*pybox[\/]src[\/]basler$ ]]; 
then
	if [ $(getconf LONG_BIT) = 64 ]
	then
		# Set to the Pylon installation, include and lib folders.
		if [ -z "$PYLON_ROOT" ]; then
			if [ -d "/opt/pylon5" ] ; then
				PYLON_ROOT="/opt/pylon5"
			elif [ -d "/opt/pylon" ] ; then
				PYLON_ROOT="/opt/pylon"
			else
				echo Pylon installation not found at the default installation path!
				echo Aborting build ...
				exit -1
			fi
			echo PYLON_ROOT variable not defined!
			echo Using discovered Pylon installation dir at $PYLON_ROOT
		fi

		CPPFLAGS=$($PYLON_ROOT/bin/pylon-config --cflags)
		LDFLAGS=$($PYLON_ROOT/bin/pylon-config --libs-rpath)
		LDLIBS=$($PYLON_ROOT/bin/pylon-config --libs)

		echo "Compiling pybasler.cpp ..."
		gcc -Wall -Wno-reorder -Wno-unknown-pragmas -c -O2 -std=c++14 \
			-fPIC -DPYBASLER_EXPORTS pybasler.cpp $CPPFLAGS \
			-I pybasler/pybasler

		echo "Linking pybasler.o ..."
		# link with the required libraries ... see the Pylon Linux manual
		gcc -shared $LDFLAGS -o pybasler64.so pybasler.o $LDLIBS
		strip --strip-all --discard-all pybasler64.so
		
		echo "Moving pybasler64.so to pybox/bin ..."
		mv pybasler64.so ../../bin/pybasler64.so
		echo "Cleanup ..."
		rm pybasler.o
		rm -f pybasler64.so
		echo "All done."
	else
		echo "This build script is intended for 64-bit OS only!"
	fi
else
	echo "Must run this script from the pybox/src/basler folder!"
fi
