#include <map>
#include <string>

#include "basler.hpp"


#if defined(_MSC_VER)
	// allow std::string copy
	#pragma warning( disable : 4996 )
	//  Microsoft 
	#ifdef PYBASLER_EXPORTS
		#define EXPORT __declspec(dllexport)
	#else
		#define IMPORT __declspec(dllimport)
	#endif
#elif defined(__GNUC__)
	//  GCC
	#ifdef PYBASLER_EXPORTS
		#define EXPORT __attribute__((visibility("default")))
	#else
		#define IMPORT
	#endif
#else
	//  do nothing and hope for the best?
	#define EXPORT
	#define IMPORT
	#pragma warning Unknown dynamic link import/export semantics.
#endif


std::map<void *, std::string> errorDescriptions;

#define SAFE_CALL(what, device) \
	int result = 0; \
	try \
{ \
	what; \
} \
	catch (const GenericException & e) \
{ \
	errorDescriptions[device].assign(e.GetDescription()); \
	result = 1; \
};

extern "C"
{
	static int initialized = 0;

	EXPORT void initializePylon(void){
		if (initialized == 0)
			PylonInitialize();
		++initialized;
	};

	EXPORT void terminatePylon(void){
		if (initialized > 0){
			--initialized;
			if (initialized == 0)
				PylonTerminate();
		}
	};

	EXPORT int findDevices(char *buffer, size_t len)
	{
		std::string str;
		size_t n=0;

		n = Basler::findAllDevices(str);
		std::strncpy(buffer, str.c_str(), len);

		return static_cast<int>(n);
	};

	EXPORT void *create(const char *serial, int numbuffers=10)
	{
		Basler *device = NULL;
		
		try
		{
			device = new Basler(serial, numbuffers);
			errorDescriptions[device] = "";
		}
		catch (const GenericException & e){
			// ignore the error
			(void)e;
			return NULL;
		}
		return static_cast<void *>(device);
    };
	
	EXPORT int destroy(void *camera)
	{
		int result = 0;

		if (errorDescriptions.count(camera) > 0){
			errorDescriptions.erase(camera);
			try
			{
				delete static_cast<Basler *>(camera);
			}
				catch (const GenericException & e){
				// ignore the error
				(void)e;
				result = 1;
			}
		}
		return result;
	};

	EXPORT int isConnected(void *camera, int *value){
		SAFE_CALL(
			*value = static_cast<int>(static_cast<Basler *>(camera)->isConnected()),
			camera);
		return result;
	};

	EXPORT int getlasterror(void *camera, char *buffer, size_t len){
		int result = 1;
		if (len > 0)
			buffer[0] = '\0';
		if (errorDescriptions.count(camera) > 0){
			buffer[errorDescriptions[camera].copy(buffer, len - 1)] = '\0';
			errorDescriptions[camera].assign("");
			result = 0;
		};
		return result;
	}

	EXPORT int flags(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<int>(
				static_cast<Basler *>(camera)->flags(property)),
			camera);
		return result;
	};

	EXPORT int isImplemented(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<int>(
				static_cast<Basler *>(camera)->isImplemented(property)),
			camera);
		return result;
	};

	EXPORT int isAvailable(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<int>(
				static_cast<Basler *>(camera)->isAvailable(property)),
			camera);
		return result;
	};

	EXPORT int isReadable(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<int>(
				static_cast<Basler *>(camera)->isReadable(property)),
			camera);
		return result;
	};

	EXPORT int isWritable(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<int>(
				static_cast<Basler *>(camera)->isWritable(property)),
			camera);
		return result;
	};

	EXPORT int commandExecute(void *camera, const char *property)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->commandExecute(property),
			camera);
		return result;
	};

	EXPORT int commandDone(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<int>(
				static_cast<Basler *>(camera)->commandDone(property)),
			camera);
		return result;
	};

	EXPORT int hasbool(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<int>(static_cast<Basler *>(camera)->hasbool(property)), 
			camera);
		return result;
	};
	EXPORT int getbool(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<Basler *>(camera)->getbool(property), 
			camera);
		return result;
	};
	EXPORT int setbool(void *camera, const char *property, 
		int value)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->setbool(property, static_cast<bool>(!!value)), 
			camera)
		return result;
	};
	
	EXPORT int hasint(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<Basler *>(camera)->hasint(property),
			camera);
		return result;
	};
	EXPORT int getint(void *camera, const char *property, int64_t *value)
	{
		SAFE_CALL(
			*value = static_cast<Basler *>(camera)->getint(property),
			camera)
			return result;
	};
	EXPORT int setint(void *camera, const char *property, 
		int64_t value)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->setint(property, value),
			camera)
			return result;
	};
	EXPORT int intrange(void *camera, const char *property,
		int64_t *minimum, int64_t *maximum)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->intrange(property, *minimum, *maximum),
			camera);
		return result;
	};

	EXPORT int hasfloat(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<Basler *>(camera)->hasfloat(property),
			camera);
		return result;
	};
	EXPORT int getfloat(void *camera, const char *property, double *value)
	{
		SAFE_CALL(
			*value = static_cast<Basler *>(camera)->getfloat(property),
			camera);
		return result;
	};
	EXPORT int setfloat(void *camera, const char *property, 
		double value)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->setfloat(property, value),
			camera);
		return result;
	};
	EXPORT int floatrange(void *camera, const char *property,
		double *minimum, double *maximum)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->floatrange(property, *minimum, *maximum),
			camera);
		return result;
	};

	EXPORT int hasenum(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<Basler *>(camera)->hasenum(property),
			camera);
		return result;
	};
	EXPORT int getenum(void *camera, const char *property, char *value, size_t len)
	{
		std::string enumstr;
		SAFE_CALL(
			static_cast<Basler *>(camera)->getenum(property, enumstr);
			value[enumstr.copy(value, len - 1)] = '\0';,
			camera);
		return result;
	};
	EXPORT int setenum(void *camera, const char *property,
		const char *value)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->setenum(property, value),
			camera);
		return result;
	};


	EXPORT int hasstr(void *camera, const char *property, int *value)
	{
		SAFE_CALL(
			*value = static_cast<Basler *>(camera)->hasstr(property),
			camera);
		return result;
	};
	EXPORT int getstr(void *camera, const char *property, char *value, size_t len)
	{
		std::string strvalue;
		SAFE_CALL(
			static_cast<Basler *>(camera)->getstr(property, strvalue);
		value[strvalue.copy(value, len - 1)] = '\0';,
			camera);
		return result;
	};
	EXPORT int setstr(void *camera, const char *property,
		const char *value)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->setstr(property, std::string(value)),
			camera);
		return result;
	};



	EXPORT int acquire(void *camera, size_t n, Basler::acq_cb_t cb)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->acquire(n, cb),
			camera);
		return result;
	};
	EXPORT int stop(void *camera)
	{
		SAFE_CALL(
			static_cast<Basler *>(camera)->stop(),
			camera);
		return result;
	};
	EXPORT int isacquiring(void *camera, int *value)
	{
		SAFE_CALL(
			*value = static_cast<int>(static_cast<Basler *>(camera)->isacquiring()),
			camera);
		return result;
	};

	#if defined(_MSC_VER)
		BOOL WINAPI DllMain(
			HINSTANCE hinstDLL,  // handle to DLL module
			DWORD fdwReason,     // reason for calling function
			LPVOID lpReserved )  // reserved
		{
			// Perform actions based on the reason for calling.
			switch( fdwReason ) 
			{ 
				case DLL_PROCESS_ATTACH:
				 // Initialize once for each new process.
				 // Return FALSE to fail DLL load.
					// PylonInitialize(); // Not allowed here ... see Pylon manual!!!
					break;

				case DLL_THREAD_ATTACH:
				 // Do thread-specific initialization.
					break;

				case DLL_THREAD_DETACH:
				 // Do thread-specific cleanup.
					break;

				case DLL_PROCESS_DETACH:
				 // Perform any necessary cleanup.
					// PylonTerminate(); // Not allowed here ... see Pylon manual!!!
					break;
			}
			return TRUE;  // Successful DLL_PROCESS_ATTACH.
		};
	#elif defined(__GNUC__)
		
		// Initialize once for each new process.
		__attribute__((constructor))
		static void Initializer(int argc, char** argv, char** envp)
		{
			// PylonInitialize(); // Not allowed here ... see Pylon manual!!!
		};

		// Perform any necessary cleanup.
		__attribute__((destructor))
		static void Finalizer()
		{
			// PylonTerminate(); // Not allowed here ... see Pylon manual!!!
		};
		
	#endif
}
