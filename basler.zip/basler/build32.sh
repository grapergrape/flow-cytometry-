#!/bin/bash

# this will make the script abort on any error
set -e
set -o pipefail

# Run this script from the pybox/src/basler folder as: ./build.sh

if [[ $(pwd) =~ ^.*pybox[\/]src[\/]basler$ ]]; 
then
	if [ $(getconf LONG_BIT) = 32 ]
	then
		# Set to the Pylon installation, include and lib folders.
		if [ -z "$PYLON_ROOT" ]; then
			if [ -d "/opt/pylon5" ] ; then
				PYLON_ROOT="/opt/pylon5"
			elif [ -d "/opt/pylon" ] ; then
				PYLON_ROOT="/opt/pylon"
			else
				echo Pylon installation not found at the default installation path!
				echo Aborting build ...
				exit -1
			fi
			echo PYLON_ROOT variable not defined!
			echo Using discovered Pylon installation dir at $PYLON_ROOT
		fi
		
		CPPFLAGS=$($PYLON_ROOT/bin/pylon-config --cflags)
		LDFLAGS=$($PYLON_ROOT/bin/pylon-config --libs-rpath)
		LDLIBS=$($PYLON_ROOT/bin/pylon-config --libs)
		
		echo "Compiling pybasler.cpp ..."
		gcc -Wall -Wno-reorder -Wno-unknown-pragmas -c -O2 -std=c++14 \
			-fPIC -DPYBASLER_EXPORTS pybasler.cpp $CPPFLAGS \
			-I pybasler/pybasler
		
		echo "Linking pybasler.o ..."
		# link with the required libraries ... see the Pylon Linux manual
		gcc -shared $LDFLAGS -o pybasler32.so pybasler.o $LDLIBS
		strip --strip-all --discard-all pybasler32.so
		
		echo "Moving pybasler32.so to pybox/bin ..."
		mv pybasler32.so ../../bin/pybasler32.so
		echo "Cleanup ..."
		rm pybasler.o
		rm -f pybasler32.so
		echo "All done."
	else
		echo "This build script is intended for 32-bit OS only!"
	fi
else
	echo "Must run this script from the pybox/src/basler folder!!"
fi
