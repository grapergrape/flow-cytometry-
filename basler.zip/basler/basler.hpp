#ifndef BASLER__
#define BASLER__

#include <vector>
#include <map>
#include <string>
#include <algorithm>
#include <thread>

#include <pylon/PylonIncludes.h>
using namespace Pylon;
using namespace GenApi;

#undef min
#undef max

class Basler{
public:
	typedef void(*acq_cb_t)(void *basler, size_t index, size_t missed,
		void *buffer, size_t height, size_t width);

	static size_t findAllDevices(std::string &buffer){
		// PylonAutoInitTerm autoInitTerm;

		CTlFactory& TlFactory = CTlFactory::GetInstance();
		DeviceInfoList_t lstDevices;
		TlFactory.EnumerateDevices(lstDevices);
		if (!lstDevices.empty()){
			DeviceInfoList_t::const_iterator it;
			for(it = lstDevices.begin(); it != lstDevices.end(); ++it){
				if (it->IsSerialNumberAvailable()){
					buffer += "serial::";
					buffer += it->GetSerialNumber();
					buffer += ";;";
				}
				if (it->IsModelNameAvailable()){
					buffer += "model::";
					buffer += it->GetModelName();
					buffer += ";;";
				}
				if (it->IsVendorNameAvailable()){
					buffer += "vendor::";
					buffer += it->GetVendorName();
					buffer += ";;";
				}
				if (it->IsDeviceClassAvailable()){
					buffer += "device::";
					buffer += it->GetDeviceClass();
					buffer += ";;";
				}
				if (it->IsFriendlyNameAvailable()){
					buffer += "name::";
					buffer += it->GetFriendlyName();
					buffer += ";;";
				}
				if (it->IsUserDefinedNameAvailable()){
					buffer += "username::";
					buffer += it->GetUserDefinedName();
					buffer += ";;";
				}
				if (it->IsFullNameAvailable()){
					buffer += "fullname::";
					buffer += it->GetFullName();
					buffer += ";;";
				}
				if (it->IsDeviceVersionAvailable()){
					buffer += "version::";
					buffer += it->GetDeviceVersion();
					buffer += ";;";
				}
				buffer += "||";
			}
		}
		return lstDevices.size();
	};

	Basler(const std::string &serial, int numbuffers=10)
		: camera_(NULL), acqisition_thread_(NULL),
			factory_(CTlFactory::GetInstance()),
			changedParameters_(), changedCallbackHandles_(),
			acqusitionErrorNumber_(0), acqusitionErrorString_("")
	{
		// PylonInitialize();

		if (serial.empty()){
			camera_ = new CInstantCamera(factory_.CreateFirstDevice());
		}
		else{

			CDeviceInfo di;
			di.SetSerialNumber(serial.c_str());
			camera_ = new CInstantCamera(factory_.CreateDevice(di));
		}
		camera_->MaxNumBuffer = std::max(numbuffers, 1);
		camera_->Open();
	};

	bool isConnected(){
		return !camera_->IsCameraDeviceRemoved();
	};

	bool isImplemented(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		return IsImplemented(control.GetNode(property.c_str()));
	};

	bool isAvailable(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		return IsAvailable(control.GetNode(property.c_str()));
	};

	bool isReadable(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		return IsReadable(control.GetNode(property.c_str()));
	};

	bool isWritable(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		return IsWritable(control.GetNode(property.c_str()));
	};

	int64_t flags(const std::string &property){
		int64_t result=0;
		INodeMap &control = camera_->GetNodeMap();
		if (IsImplemented(control.GetNode(property.c_str()))){
			result |= 1;
			if (IsAvailable(control.GetNode(property.c_str())))
				result |= 2;
			if (IsReadable(control.GetNode(property.c_str())))
				result |= 4;
			if (IsWritable(control.GetNode(property.c_str())))
				result |= 8;
		};
		return result;
	};

	void setbool(const std::string &property, bool value){
		INodeMap &control = camera_->GetNodeMap();
		const CBooleanPtr node = control.GetNode(property.c_str());
		if (IsWritable(node))
			node->SetValue(value);
	};
	bool getbool(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		const CBooleanPtr node = control.GetNode(property.c_str());
		return node->GetValue();
	};
	bool hasbool(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		const CBooleanPtr node = control.GetNode(property.c_str());
		return node.IsValid();
	};

	void setint(const std::string &property, int64_t value){
		INodeMap &control = camera_->GetNodeMap();
		const CIntegerPtr node = control.GetNode(property.c_str());
		if (IsWritable(node)){
			value = std::max(std::min(value, node->GetMax()), node->GetMin());
			node->SetValue(value);
		}
	};
	int64_t getint(const std::string &property){
		INodeMap &control = this->camera_->GetNodeMap();
		const CIntegerPtr node = control.GetNode(property.c_str());
		return node->GetValue();
	};
	bool hasint(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		const CIntegerPtr node = control.GetNode(property.c_str());
		return node.IsValid();
	};
	void intrange(const std::string &property, int64_t &minimum, int64_t &maximum){
		INodeMap &control = this->camera_->GetNodeMap();
		const CIntegerPtr node = control.GetNode(property.c_str());
		if (node.IsValid()){
			minimum = node->GetMin();
			maximum = node->GetMax();
		};
	}

	void setfloat(const std::string &property, double value){
		INodeMap &control = camera_->GetNodeMap();
		const CFloatPtr node = control.GetNode(property.c_str());
		if (IsWritable(node)){
			value = std::max(std::min(value, node->GetMax()), node->GetMin());
			node->SetValue(value);
		}
	};
	double getfloat(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		const CFloatPtr node = control.GetNode(property.c_str());
		return node->GetValue();
	};
	bool hasfloat(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		const CFloatPtr node = control.GetNode(property.c_str());
		return node.IsValid();
	};
	void floatrange(const std::string &property, double &minimum, double &maximum){
		INodeMap &control = this->camera_->GetNodeMap();
		const CFloatPtr node = control.GetNode(property.c_str());
		if (node.IsValid()){
			minimum = node->GetMin();
			maximum = node->GetMax();
		};
	}
	
	void setstr(const std::string &property, const std::string &value){
		INodeMap &control = camera_->GetNodeMap();
		const CStringPtr node = control.GetNode(property.c_str());
		if (IsWritable(node)){
			node->SetValue(value.c_str());
		}
	};
	std::string &getstr(const std::string &property, std::string &value){
		INodeMap &control = camera_->GetNodeMap();
		const CStringPtr node = control.GetNode(property.c_str());
		return value.assign(node->GetValue());
	};
	bool hasstr(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		const CStringPtr node = control.GetNode(property.c_str());
		return node.IsValid();
	};

	void getenumvalues(const std::string &property, std::vector<std::string> &enums){
		INodeMap &control = camera_->GetNodeMap();
		const CEnumerationPtr node = control.GetNode(property.c_str());
		NodeList_t entries;
		node->GetEntries(entries);
		for (NodeList_t::iterator it = entries.begin(); it != entries.end(); ++it) {
			CEnumEntryPtr pEntry = *it;
			enums.push_back(std::string(pEntry->ToString()));
		}

	}
	void setenum(const std::string &property, const char *value){
		INodeMap &control = camera_->GetNodeMap();
		const CEnumerationPtr node = control.GetNode(property.c_str());
		if (IsWritable(node) && IsAvailable(node->GetEntryByName(value)))
			node->FromString(value);
	}
	std::string & getenum(const std::string &property, std::string &result){
		INodeMap &control = camera_->GetNodeMap();
		const CEnumerationPtr node = control.GetNode(property.c_str());
		result.assign(node->ToString());
		return result;
	};
	bool hasenum(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		const CEnumerationPtr node = control.GetNode(property.c_str());
		return node.IsValid();
	};

	void commandExecute(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		const CCommandPtr node = control.GetNode(property.c_str());
		if (IsAvailable(node)){
			node->Execute();
		}
	};
	bool commandDone(const std::string &property){
		INodeMap &control = camera_->GetNodeMap();
		bool result=true;
		const CCommandPtr node = control.GetNode(property.c_str());
		if (IsAvailable(node)){
			result = node->IsDone();
		}
		return result;
	};

	void acquire(size_t n, acq_cb_t cb){
		if (!isacquiring()){ 
			wait();
			acqisition_thread_ = new std::thread(&Basler::acquire_proc_, this, n, cb);
		}
	}
	void acquire_proc_(size_t n, acq_cb_t cb){
		size_t index = 0;
		camera_->StartGrabbing(n);
		CGrabResultPtr ptrGrabResult;

		while (camera_->IsGrabbing())
		{
			// Wait for an image and then retrieve it. A timeout of 5000 ms is used.
			if (camera_->RetrieveResult(1000, ptrGrabResult, TimeoutHandling_Return)){
				// Image grabbed successfully?
				if (ptrGrabResult->GrabSucceeded()){
					// Access the image data.
					if (cb){
						cb(this, ++index, ptrGrabResult->GetNumberOfSkippedImages(),
							ptrGrabResult->GetBuffer(),
							ptrGrabResult->GetHeight(), ptrGrabResult->GetWidth());
					};
				}
				else{
					// failed to grabb
					acqusitionErrorNumber_ = ptrGrabResult->GetErrorCode();
					acqusitionErrorString_.assign(ptrGrabResult->GetErrorDescription());
				}
			}
		}
	};

	void addmonitor(const char *property){
		if (changedCallbackHandles_.count(property) <= 0){
			INodeMap &control = camera_->GetNodeMap();
			INode *node=control.GetNode(property);
			changedCallbackHandles_[property] = Register(node, *this, &Basler::changed_);
		}
	};
	
	void removemonitor(const char *property){
		if (changedCallbackHandles_.count(property) > 0){
			INodeMap &control = camera_->GetNodeMap();
			INode *node = control.GetNode(property);
			node->DeregisterCallback(changedCallbackHandles_[property]);
			changedCallbackHandles_.erase(property);
		}
	}

	void wait(void){
		if (acqisition_thread_ && std::this_thread::get_id() != acqisition_thread_->get_id()){
			acqisition_thread_->join();
			delete acqisition_thread_;
			acqisition_thread_ = NULL;
		}
	};

	void stop(){
		camera_->StopGrabbing();
		wait();
	};

	bool isacquiring(){
		return camera_->IsGrabbing();
	};

	~Basler(){
		// PylonTerminate();

		if (this->camera_){

			for (auto it = changedCallbackHandles_.begin(); it != changedCallbackHandles_.end();){
				removemonitor(it++->first.c_str());
			}
			this->stop();
			this->camera_->Close();
			delete this->camera_;
		}
	};

private:
	void changed_(GenApi::INode* pNode){
		if (std::find(changedParameters_.begin(), changedParameters_.end(), pNode->GetName().c_str()) == changedParameters_.end()) {
			changedParameters_.push_back(pNode->GetName().c_str());
		}
	};

	CInstantCamera *camera_;
	Pylon::CTlFactory& factory_;
	int acqusitionErrorNumber_;
	std::string acqusitionErrorString_;
	std::thread *acqisition_thread_;
	
	std::vector<std::string> changedParameters_;
	std::map<std::string, CallbackHandleType> changedCallbackHandles_;
};

#endif // BASLER__
