// basler.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "../../basler.hpp"

void acqcb(void *device, size_t index, size_t missed,
		void *buffer, size_t height, size_t width){
	Basler *basler = static_cast<Basler *>(device);
	printf("Frame %d; Missed %d, Height %d; Width %d\n", index, missed, height, width);
	basler->setfloat("ExposureTime", 100.0*index);
	printf("ExposureTime %.1f\n", basler->getfloat("ExposureTime"));
	if (index >= 10)
		basler->stop();
};

int _tmain(int argc, _TCHAR* argv[])
{
	int width, pf;
	double gain, fps;
	std::string format;
	std::string msg;
	Basler *dev=NULL;
	bool has;

	PylonInitialize();
	try
	{
		dev = new Basler("22066885");
		delete dev;
		dev = new Basler("22066885");

		dev->addmonitor("Width");
		dev->addmonitor("Gain");
		dev->addmonitor("PixelFormat");
		
		has = dev->hasbool("Width");

		has = dev->hasint("Width");
		dev->getint("Width");

		dev->setint("Width", 1024);
		width = dev->getint("Width");

		has = dev->hasfloat("Gain");
		gain = dev->getfloat("Gain");
		dev->setfloat("Gain", 5.1);
		gain = dev->getfloat("Gain");

		fps = dev->getfloat("ResultingFrameRate");

		has = dev->hasenum("Gain");
		has = dev->hasenum("PixelFormat");
		dev->setenum("PixelFormat", "Mono16");
		dev->getenum("PixelFormat", format);
		dev->getenum("PixelFormat", format);
		dev->getenum("PixelSize", format);
		dev->getenum("TriggerSelector", format);
		std::vector<std::string> values;
		dev->getenumvalues("PixelFormat", values);

		dev->acquire(-1, acqcb);
		dev->wait();

		has = dev->isacquiring();
	}
		catch (const GenericException & e)
	{
		printf(e.GetDescription());
	};
	if (dev)
		delete dev;
	PylonTerminate();
	return 0;
}